export const MAX_ROUNDS = 10
